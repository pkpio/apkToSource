package de.ecspride.crackme;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.UnsupportedEncodingException;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends ActionBarActivity
{
  private static byte[] decrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "AES");
    Cipher localCipher = Cipher.getInstance("AES");
    localCipher.init(2, localSecretKeySpec);
    return localCipher.doFinal(paramArrayOfByte2);
  }

  private static byte[] encrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "AES");
    Cipher localCipher = Cipher.getInstance("AES");
    localCipher.init(1, localSecretKeySpec);
    return localCipher.doFinal(paramArrayOfByte2);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903063);
    ((Button)findViewById(2131296321)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        byte[] arrayOfByte1 = { 103, 71, 49, 84, 34, 36, 112, 30, 63, 63, 93, -121, -81, 125, -68, -38 };
        try
        {
          byte[] arrayOfByte2 = MainActivity.decrypt(arrayOfByte1, new byte[] { 117, 89, -27, -43, 90, -67, 123, 26, 90, 99, -59, 73, -74, -13, -46, -100, 44, 74, 125, 37, 47, -31, 40, 7, 82, -37, 20, -99, 46, -11, -17, 3 });
          EditText localEditText = (EditText)MainActivity.this.findViewById(2131296320);
          if (new String(arrayOfByte2, "UTF-8").equals(localEditText.getText().toString()))
          {
            Toast.makeText(MainActivity.this, "Congrats!", 1).show();
            return;
          }
          Toast.makeText(MainActivity.this, "Nice try, but it's wrong...", 1).show();
          return;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          localUnsupportedEncodingException.printStackTrace();
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    });
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492864, paramMenu);
    return true;
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 2131296322)
      return true;
    return super.onOptionsItemSelected(paramMenuItem);
  }
}

/* Location:           /home/praveen/works/apkToSource/sample/CrackMeApplication-dex2jar.jar
 * Qualified Name:     de.ecspride.crackme.MainActivity
 * JD-Core Version:    0.6.2
 */