package de.ecspride.crackme;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           /home/praveen/works/apkToSource/sample/CrackMeApplication-dex2jar.jar
 * Qualified Name:     de.ecspride.crackme.BuildConfig
 * JD-Core Version:    0.6.2
 */