package android.support.v4.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter
  implements ViewPropertyAnimatorListener
{
  public void onAnimationCancel(View paramView)
  {
  }

  public void onAnimationEnd(View paramView)
  {
  }

  public void onAnimationStart(View paramView)
  {
  }
}

/* Location:           /home/praveen/works/apkToSource/sample/CrackMeApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPropertyAnimatorListenerAdapter
 * JD-Core Version:    0.6.2
 */