package android.support.v4.view;

import android.view.View;

public class ViewCompatKitKat
{
  public static int getAccessibilityLiveRegion(View paramView)
  {
    return paramView.getAccessibilityLiveRegion();
  }

  public static void setAccessibilityLiveRegion(View paramView, int paramInt)
  {
    paramView.setAccessibilityLiveRegion(paramInt);
  }
}

/* Location:           /home/praveen/works/apkToSource/sample/CrackMeApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatKitKat
 * JD-Core Version:    0.6.2
 */