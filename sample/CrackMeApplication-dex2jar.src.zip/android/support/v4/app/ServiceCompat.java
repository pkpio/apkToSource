package android.support.v4.app;

public class ServiceCompat
{
  public static final int START_STICKY = 1;
}

/* Location:           /home/praveen/works/apkToSource/sample/CrackMeApplication-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ServiceCompat
 * JD-Core Version:    0.6.2
 */